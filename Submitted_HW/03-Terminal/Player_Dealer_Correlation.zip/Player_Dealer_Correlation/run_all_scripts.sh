#!/bin/bash
sh 0310_win_loss_player_data\:05\:00\:00AM.sh
sh 0310_win_loss_player_data\:08\:00\:00AM.sh
sh 0310_win_loss_player_data\:02\:00\:00PM.sh
sh 0310_win_loss_player_data\:08\:00\:00PM.sh
sh 0310_win_loss_player_data\:11\:00\:00PM.sh
sh 0312_win_loss_player_data\:05\:00\:00AM.sh
sh 0312_win_loss_player_data\:08\:00\:00AM.sh
sh 0312_win_loss_player_data\:02\:00\:00PM.sh
sh 0312_win_loss_player_data\:08\:00\:00PM.sh
sh 0312_win_loss_player_data\:11\:00\:00PM.sh
sh 0315_win_loss_player_data\:05\:00\:00AM.sh
sh 0315_win_loss_player_data\:08\:00\:00AM.sh
sh 0315_win_loss_player_data\:02\:00\:00PM.sh

